//
//  events.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 ankam srigiriraju. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Tejasvi SrigiriRaju and Jyostna Ankam
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import Foundation
import UIKit

class events {
    var eventid:String!
    var eventname:String!
    var eventlocation:String!
    var eventdate:String!
    var eventstaff:String!
    
    
    init(eventid:String, eventname: String, eventlocation: String, eventdate: String, eventstaff: String) {
        self.eventid=eventid
        self.eventname=eventname
        self.eventlocation=eventlocation
        self.eventdate=eventdate
        self.eventstaff=eventstaff
        
        
    }
    
}

