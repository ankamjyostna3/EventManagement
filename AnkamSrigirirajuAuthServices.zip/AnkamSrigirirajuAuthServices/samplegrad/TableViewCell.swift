//
//  TableViewCell.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 ankam srigiriraju. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Tejasvi SrigiriRaju and Jyostna Ankam
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var Eventname: UILabel!

    @IBOutlet weak var eventTimelabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
