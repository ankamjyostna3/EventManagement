//
//  StaffHomeViewController.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 ankam srigiriraju. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Tejasvi SrigiriRaju and Jyostna Ankam
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class StaffHomeViewController: UIViewController {
//user email 
    var name:String!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
   // @IBOutlet weak var logout: UIButton!
    //Redirects to login page if logout is clicked
    @IBAction func logout(_ sender: Any) {
        
        
            }
    //passes name to table stafftable view controller so taht that particular person events can be fetched
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if(segue.identifier == "stafftable"){
            let stafftablevc = segue.destination as! StaffTableViewController
            
            stafftablevc.name = name
        }
    }
        // Pass the selected object to the new view controller.

}
    


