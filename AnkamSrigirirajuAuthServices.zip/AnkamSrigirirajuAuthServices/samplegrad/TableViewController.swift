//
//  TableViewController.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 ankam srigiriraju. All rights reserved.
//
/*********************************************************************************************
                        GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Tejasvi SrigiriRaju and Jyostna Ankam
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class TableViewController: UITableViewController {

    var eventsObject=[events]()
    
    //var newsArray:NSArray=[]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        fetchJSONdata()
        // Uncomment the following line to preserve selection between presentations
       
    }
  
    @IBAction func backButton(_ sender: UIButton) {
        
        
    }
    
    //This functions calls the php service and get the current list of all the events as a jason format and store in eventobject so that it can be displayed in table view.
    func fetchJSONdata(){
        
        
        // Fetching FoxSports latest news articles.
        let api_url=URL(string: "http://students.cs.niu.edu/~z1789593/ios/currentevents.php")
        
        //create a URL request with API addreess
        let urlRequest=URLRequest(url: api_url!)
        
        //submit a request to get the JSOn data
        let task=URLSession.shared.dataTask(with: urlRequest){
            (data,response,error) in
            
            //if there's an error print the error and break the loop.
            if(error != nil){
                print(error!)
            }//end error if
            
            //if there is no error fetch the json data
            if let content=data{
               
                do{
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                     //reads data from json object. and add to eb=ventsobject
                    if let resultjson = jsonObject["result"] as? [[String:AnyObject]]{
                        for item in resultjson{
                            
                            if let eventid = item["eventid"], let eventname = item["eventname"] as? String, let eventlocation = item["eventlocation"] as? String, let eventdate = item["eventdate"] as? String , let eventstaff = item["eventstaff"] as? String{
                                
                                self.eventsObject.append(events(eventid:eventid as! String, eventname: eventname, eventlocation: eventlocation,eventdate: eventdate, eventstaff: eventstaff))
                                
                                //print(<#T##items: Any...##Any#>)
                            } //end if
                            
                        } //end for loop
                        
                    } //end if
                    //if you are using a table view, you would reload the data
                    self.tableView.reloadData()
                }//end do
                catch{
                    print(error)
                }//end catch
            }//end else if
            
        }//end get data session
        task.resume()
        
    }//end fecthJsondata function
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.eventsObject.count
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        
    {
        
        //allocate the table view cell with the values
        
         let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        
        let event:events = eventsObject[indexPath.row]
        
        // Configure the cell...
        
        cell.Eventname.text = event.eventname
        cell.eventTimelabel.text = event.eventdate
       
        return cell
    }
    
    
    //send the event details to detail view for display
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        if(segue.identifier=="detailView"){
            let detailVC=segue.destination as! DetailViewController
            
            //sending data to the view controller
            if let indexPath=self.tableView.indexPathForSelectedRow{
                let eve:events=eventsObject[indexPath.row]
                detailVC.navigationItem.title=eve.eventname
                detailVC.eventname = eve.eventname
                detailVC.eventtime = eve.eventdate
                detailVC.eventlocation = eve.eventlocation
                detailVC.eventstaff = eve.eventstaff
                
            }
        }
        // Pass the selected object to the new view controller.
    }
    
    
    

}
