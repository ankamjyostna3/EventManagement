//
//  DetailViewController.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 ankam srigiriraju. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Tejasvi SrigiriRaju and Jyostna Ankam
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class DetailViewController: UIViewController {

    var eventname: String!
    var eventlocation: String!
    var eventtime:String!
    var eventstaff:String!
    
    @IBOutlet weak var eventnameLabel: UILabel!
    @IBOutlet weak var eventLocationLabel: UILabel!
    @IBOutlet weak var eventTimeLabel: UILabel!
    @IBOutlet weak var eventStaffLabel: UILabel!
    
    
    // Diaplays details of event when user click on particular table view..
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        eventnameLabel.text = eventname
        eventTimeLabel.text = eventtime
        eventStaffLabel.text = eventstaff
        eventLocationLabel.text = eventlocation
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
